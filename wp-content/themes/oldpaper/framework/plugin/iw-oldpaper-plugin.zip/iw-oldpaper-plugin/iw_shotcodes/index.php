<?php

require_once('editor/iw_buttons.php');

require_once('shortcodes/iw_slider.php');
require_once('shortcodes/iw_carousel.php');
require_once('shortcodes/iw_fontawesome.php');
require_once('shortcodes/iw_code.php');
require_once('shortcodes/iw_grid.php');
require_once('shortcodes/iw_alerts.php');
require_once('shortcodes/iw_hr.php');
require_once('shortcodes/iw_dropcap.php');
require_once('shortcodes/iw_bottone.php');
require_once('shortcodes/iw_lastposts.php');
require_once('shortcodes/iw_progress.php');
require_once('shortcodes/iw_lead.php');

?>