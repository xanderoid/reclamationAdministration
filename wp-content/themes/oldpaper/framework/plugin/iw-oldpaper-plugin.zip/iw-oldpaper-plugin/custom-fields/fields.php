<?php

require_once('cpt-breaking.php');

require_once('iw_page.php');
require_once('iw_page-slider.php');

require_once('iw_post-audio.php');
require_once('iw_post-quote.php');
require_once('iw_post-video.php');

?>