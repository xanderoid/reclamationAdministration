<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>
	
	<div class="widget">
		<h4><span><?php _e('Sidebar', 'oldpaper') ?></span></h4>
		<p><?php _e('Use the Admin widget page to populate the sidebar.', 'oldpaper') ?></p>
	</div>
						
<?php endif; ?>